﻿namespace WinFormUI
{
    partial class BookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.authorLabel = new System.Windows.Forms.Label();
            this.titleNameLabel = new System.Windows.Forms.Label();
            this.authorNameText = new System.Windows.Forms.TextBox();
            this.titleNameText = new System.Windows.Forms.TextBox();
            this.addTitleAuthorHeader = new System.Windows.Forms.Label();
            this.listAuthorBookHeader = new System.Windows.Forms.Label();
            this.listAuthorBookBox = new System.Windows.Forms.ListBox();
            this.addAuthorBookButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.publisherNameText = new System.Windows.Forms.TextBox();
            this.publisherNameLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // authorLabel
            // 
            this.authorLabel.AutoSize = true;
            this.authorLabel.Location = new System.Drawing.Point(46, 101);
            this.authorLabel.Name = "authorLabel";
            this.authorLabel.Size = new System.Drawing.Size(105, 36);
            this.authorLabel.TabIndex = 0;
            this.authorLabel.Text = "Author";
            this.authorLabel.Click += new System.EventHandler(this.authorLabel_Click);
            // 
            // titleNameLabel
            // 
            this.titleNameLabel.AutoSize = true;
            this.titleNameLabel.Location = new System.Drawing.Point(46, 190);
            this.titleNameLabel.Name = "titleNameLabel";
            this.titleNameLabel.Size = new System.Drawing.Size(71, 36);
            this.titleNameLabel.TabIndex = 1;
            this.titleNameLabel.Text = "Title";
            this.titleNameLabel.Click += new System.EventHandler(this.titleNameLabel_Click);
            // 
            // authorNameText
            // 
            this.authorNameText.Location = new System.Drawing.Point(52, 137);
            this.authorNameText.Name = "authorNameText";
            this.authorNameText.Size = new System.Drawing.Size(234, 41);
            this.authorNameText.TabIndex = 2;
            this.authorNameText.TextChanged += new System.EventHandler(this.authorNameText_TextChanged);
            // 
            // titleNameText
            // 
            this.titleNameText.Location = new System.Drawing.Point(52, 226);
            this.titleNameText.Name = "titleNameText";
            this.titleNameText.Size = new System.Drawing.Size(234, 41);
            this.titleNameText.TabIndex = 3;
            this.titleNameText.TextChanged += new System.EventHandler(this.titleNameText_TextChanged);
            // 
            // addTitleAuthorHeader
            // 
            this.addTitleAuthorHeader.AutoSize = true;
            this.addTitleAuthorHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addTitleAuthorHeader.Location = new System.Drawing.Point(32, 42);
            this.addTitleAuthorHeader.Name = "addTitleAuthorHeader";
            this.addTitleAuthorHeader.Size = new System.Drawing.Size(438, 52);
            this.addTitleAuthorHeader.TabIndex = 4;
            this.addTitleAuthorHeader.Text = "Add Title and Author";
            this.addTitleAuthorHeader.Click += new System.EventHandler(this.addTitleAuthorHeader_Click);
            // 
            // listAuthorBookHeader
            // 
            this.listAuthorBookHeader.AutoSize = true;
            this.listAuthorBookHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listAuthorBookHeader.Location = new System.Drawing.Point(676, 42);
            this.listAuthorBookHeader.Name = "listAuthorBookHeader";
            this.listAuthorBookHeader.Size = new System.Drawing.Size(445, 52);
            this.listAuthorBookHeader.TabIndex = 5;
            this.listAuthorBookHeader.Text = "List Author and Book";
            this.listAuthorBookHeader.Click += new System.EventHandler(this.listAuthorBookHeader_Click);
            // 
            // listAuthorBookBox
            // 
            this.listAuthorBookBox.FormattingEnabled = true;
            this.listAuthorBookBox.ItemHeight = 36;
            this.listAuthorBookBox.Location = new System.Drawing.Point(599, 101);
            this.listAuthorBookBox.Name = "listAuthorBookBox";
            this.listAuthorBookBox.Size = new System.Drawing.Size(869, 364);
            this.listAuthorBookBox.TabIndex = 6;
            this.listAuthorBookBox.SelectedIndexChanged += new System.EventHandler(this.listAuthorBookBox_SelectedIndexChanged);
            // 
            // addAuthorBookButton
            // 
            this.addAuthorBookButton.Location = new System.Drawing.Point(52, 396);
            this.addAuthorBookButton.Name = "addAuthorBookButton";
            this.addAuthorBookButton.Size = new System.Drawing.Size(234, 69);
            this.addAuthorBookButton.TabIndex = 7;
            this.addAuthorBookButton.Text = "Add Author";
            this.addAuthorBookButton.UseVisualStyleBackColor = true;
            this.addAuthorBookButton.Click += new System.EventHandler(this.addAuthorBookButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(653, 502);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(747, 327);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // publisherNameText
            // 
            this.publisherNameText.Location = new System.Drawing.Point(52, 322);
            this.publisherNameText.Name = "publisherNameText";
            this.publisherNameText.Size = new System.Drawing.Size(234, 41);
            this.publisherNameText.TabIndex = 10;
            this.publisherNameText.TextChanged += new System.EventHandler(this.publisherNameText_TextChanged);
            // 
            // publisherNameLabel
            // 
            this.publisherNameLabel.AutoSize = true;
            this.publisherNameLabel.Location = new System.Drawing.Point(54, 283);
            this.publisherNameLabel.Name = "publisherNameLabel";
            this.publisherNameLabel.Size = new System.Drawing.Size(141, 36);
            this.publisherNameLabel.TabIndex = 11;
            this.publisherNameLabel.Text = "Publisher";
            this.publisherNameLabel.Click += new System.EventHandler(this.publisherNameLabel_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(41, 541);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 41);
            this.textBox1.TabIndex = 12;
            // 
            // BookForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1907, 841);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.publisherNameLabel);
            this.Controls.Add(this.publisherNameText);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.addAuthorBookButton);
            this.Controls.Add(this.listAuthorBookBox);
            this.Controls.Add(this.listAuthorBookHeader);
            this.Controls.Add(this.addTitleAuthorHeader);
            this.Controls.Add(this.titleNameText);
            this.Controls.Add(this.authorNameText);
            this.Controls.Add(this.titleNameLabel);
            this.Controls.Add(this.authorLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.Name = "BookForm";
            this.Text = "DBProject by Chijioke and Jim";
            this.Load += new System.EventHandler(this.BookForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label authorLabel;
        private System.Windows.Forms.Label titleNameLabel;
        private System.Windows.Forms.TextBox authorNameText;
        private System.Windows.Forms.TextBox titleNameText;
        private System.Windows.Forms.Label addTitleAuthorHeader;
        private System.Windows.Forms.Label listAuthorBookHeader;
        private System.Windows.Forms.ListBox listAuthorBookBox;
        private System.Windows.Forms.Button addAuthorBookButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox publisherNameText;
        private System.Windows.Forms.Label publisherNameLabel;
        private System.Windows.Forms.TextBox textBox1;
    }
}

