﻿using WinFormUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class BookForm : Form
    {
        List<Book> books = new List<Book>();

        public BookForm()
        {
            InitializeComponent();

            LoadBookList();
        }

        private void LoadBookList()
        {
            
            books = SQLiteDataAccess.LoadBook();
            SQLiteDataAccess dataAccess = new SQLiteDataAccess();
            this.dataGridView1.DataSource = dataAccess.GetDataFromSQLite("select * from Book");

            WireUpBookList();
        }

        private void WireUpBookList()
        {
            listAuthorBookBox.DataSource = null;
            listAuthorBookBox.DataSource = books;
            listAuthorBookBox.DisplayMember = "FullInfo";
        }

        private void refreshListButton_Click(object sender, EventArgs e)
        {
            LoadBookList();
        }

        private void listAuthorBookBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void addAuthorBookButton_Click(object sender, EventArgs e)
        {
            Book b = new Book();

            b.Author = authorNameText.Text;
            b.Title = titleNameText.Text;
            b.Publisher = publisherNameText.Text;

            SQLiteDataAccess.SaveBook(b);

            authorNameText.Text = "";
            titleNameText.Text = "";
            publisherNameText.Text = "";
            LoadBookList();
        }

        private void authorLabel_Click(object sender, EventArgs e)
        {

        }

        private void authorNameText_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void titleNameText_TextChanged(object sender, EventArgs e)
        {

        }

        private void BookForm_Load(object sender, EventArgs e)
        {

        }

        private void addTitleAuthorHeader_Click(object sender, EventArgs e)
        {

        }

        private void listAuthorBookHeader_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void publisherNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void publisherNameText_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
