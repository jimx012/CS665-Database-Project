﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace WinFormUI
{
    public class Borrow
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public long PhoneNumber { get; set; }
        public string Address { get; set; }

        public string FullInfo
        {
            get
            {
                return $"Full Name:{FullName}  Phone Number:{PhoneNumber}  Address:{Address}";
            }
        }
    }


}
