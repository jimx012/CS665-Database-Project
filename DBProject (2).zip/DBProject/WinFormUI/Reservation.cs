﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormUI
{
    public class Reservation
    {
        public int Id { get; set; }
        public int BookId { get; set; }
        public int BorrowerId { get; set; }
        public string ReservationDate { get; set; }
        public string PickupDate { get; set; }


        public string FullInfo
        {
            get
            {
                return $"BookId:{BookId}  BorrowerId:{BorrowerId}  ReservationDate:{ReservationDate} PickupDate:{PickupDate}";
            }
        }
    }
}