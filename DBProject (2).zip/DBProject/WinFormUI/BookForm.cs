﻿using WinFormUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;
using System.Data.SQLite;
using System.Data.SqlClient;

namespace WinFormUI
{
    public partial class BookForm : Form
    {
        List<Book> books = new List<Book>();

        public BookForm()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += DataGridView1_SelectionChanged;
            LoadBookList();
        }

        private void LoadBookList()
        {

            books = SQLiteDataAccess.LoadBook();
            SQLiteDataAccess dataAccess = new SQLiteDataAccess();
            this.dataGridView1.DataSource = dataAccess.GetDataFromSQLite("select * from Book");

        }



        //private void refreshListButton_Click(object sender, EventArgs e)
        //{
        //    LoadBookList();
        //}

        private void listAuthorBookBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void addAuthorBookButton_Click(object sender, EventArgs e)
        {
            Book b = new Book();

            b.Author = authorNameText.Text;
            b.Title = titleNameText.Text;
            b.Publisher = publisherNameText.Text;

            SQLiteDataAccess.SaveBook(b);

            authorNameText.Text = "";
            titleNameText.Text = "";
            publisherNameText.Text = "";
            LoadBookList();
        }

        private void authorLabel_Click(object sender, EventArgs e)
        {

        }

        private void authorNameText_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void titleNameText_TextChanged(object sender, EventArgs e)
        {

        }

        private void BookForm_Load(object sender, EventArgs e)
        {

        }

        private void addTitleAuthorHeader_Click(object sender, EventArgs e)
        {

        }

        private void listAuthorBookHeader_Click(object sender, EventArgs e)
        {

        }
        private void DataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewRow row = GetDataFromSelectedRows();
            if (row != null)
            {
                // Use the returned row
                // Example: Print the values of all cells in the row to the Console
                this.authorNameText.Text = row.Cells[1].Value.ToString();
                this.titleNameText.Text = row.Cells[2].Value.ToString();
                this.publisherNameText.Text = row.Cells[3].Value.ToString();
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = GetDataFromSelectedRows();
            if (row != null)
            {
                // Use the returned row
                // Example: Print the values of all cells in the row to the Console
                this.authorNameText.Text = row.Cells[1].Value.ToString();
                this.titleNameText.Text = row.Cells[2].Value.ToString();
                this.publisherNameText.Text = row.Cells[3].Value.ToString();
            }
        }

        private void publisherNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void publisherNameText_TextChanged(object sender, EventArgs e)
        {

        }

        private void borrowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BorrowForm borrow = new BorrowForm();

            borrow.Show();

            this.Hide();
        }
        private DataGridViewRow GetDataFromSelectedRows()
        {
            // Check if any rows are selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the first selected row
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                // Return the selected row
                return row;
            }
            else
            {

                return null;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = GetDataFromSelectedRows();
            if (row != null)
            {
                int bookID;
                if (int.TryParse(row.Cells[0].Value.ToString(), out bookID))
                {
                    // Get the updated information from the text boxes
                    string author = this.authorNameText.Text;
                    string title = this.titleNameText.Text;
                    string publisher = this.publisherNameText.Text;

                    // Update the book information in the database
                    SQLiteDataAccess.UpdateBook(new Book { Id = bookID, Author = author, Title = title, Publisher = publisher });

                    // Reload the data in the DataGridView
                    SQLiteDataAccess.LoadBook();
                }
                else
                {
                    MessageBox.Show("Invalid book ID");
                }
            }
        }


        private void deleteButton_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = GetDataFromSelectedRows();

            if (selectedRow != null)
            {
                int bookID;
                if (int.TryParse(selectedRow.Cells[0].Value.ToString(), out bookID)) // validate bookID
                {
                    SQLiteDataAccess.DeleteBook(bookID);
                    dataGridView1.Rows.Remove(selectedRow);
                    MessageBox.Show("Book deleted successfully.");
                    // Load the book data again after deleting the book
                    dataGridView1.DataSource = SQLiteDataAccess.LoadBook();
                }
                else
                {
                    MessageBox.Show("Invalid book ID"); // show error message
                }
            }
        }

        private void subqueryButton_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Book WHERE Id IN (SELECT BookId FROM Loan WHERE BorrowerId = 1)";
            List<Book> books;

            using (IDbConnection cnn = new SQLiteConnection(SQLiteDataAccess.LoadConnectionString()))
            {
                books = cnn.Query<Book>(query, new DynamicParameters()).ToList();
            }

            dataGridView1.DataSource = books;
        }

        private void joinButton_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Book INNER JOIN Reservation ON Book.Id = Reservation.BookId WHERE Reservation.BookId = 3";
            List<Book> books;

            using (IDbConnection cnn = new SQLiteConnection(SQLiteDataAccess.LoadConnectionString()))
            {
                books = cnn.Query<Book>(query, new DynamicParameters()).ToList();
            }

            dataGridView1.DataSource = books;
        }

        private void tablesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void booksToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}

