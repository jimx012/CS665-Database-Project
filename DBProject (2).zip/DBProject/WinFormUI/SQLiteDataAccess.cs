﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormUI
{
    public class SQLiteDataAccess
    {
        public static List<Book> LoadBook()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<Book>("select * from Book", new DynamicParameters());
                return output.ToList(); 
            }
        }

        public static List<Borrow> LoadBorrow()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<Borrow>("select * from Borrower", new DynamicParameters());
                return output.ToList();
            }
        }

        public static List<Loan> LoadLoan()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<Loan>("select * from Loan", new DynamicParameters());
                return output.ToList();
            }
        }


        public DataTable GetDataFromSQLite(string query)
        {
            DataTable dataTable = new DataTable();
            using (SQLiteConnection connection = new SQLiteConnection(LoadConnectionString()))
            {
                connection.Open();
                using (SQLiteCommand command = new SQLiteCommand(query, connection))
                {
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            return dataTable;
        }

        public static void SaveBook(Book books)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Book (Title, Author, Publisher) values (@Title, @Author, @Publisher)", books);
            }
        }
        public static void SaveBorrow(Borrow borrow)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Borrower (FullName, PhoneNumber, Address) values (@FullName, @PhoneNumber, @Address)", borrow);
            }
        }

        public static void SaveLoan(Loan loans)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Loan (BookId, BorrowerId, LoanDate, DueDate, ReturnDate) values (@BookId, @BorrowerId, @LoanDate, @DueDate)", loans);
            }
        }

        public static void DeleteBook(int bookID)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("delete from Book where Id = @Id", new { Id = bookID });
            }
        }
        public static void DeleteBorrower(int ID)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("delete from Borrower where Id = @Id", new { Id = ID });
            }
        }

        public static void DeleteLoan(int ID)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("delete from Laon where Id = @Id", new { Id = ID });
            }
        }

        public static void UpdateBook(Book book)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("update Book set Title = @Title, Author = @Author, Publisher = @Publisher where Id = @Id", book);
            }
        }

        public static void UpdateBorrower(Borrow borrow)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("update Borrower set FullName = @FullName, PhoneNumber = @PhoneNumber, Address = @Address where Id = @Id", borrow);
            }
        }
        public static void UpdateLoan(Loan loans)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("update Loan set BookId = @BookId, BorrowerId = @BorrowerId, LoanDate = @LoanDate, DueDate = @DueDate where Id = @Id", loans);
            }
        }



        public static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }
    }
}
