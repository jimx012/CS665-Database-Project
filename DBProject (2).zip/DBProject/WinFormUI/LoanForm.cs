﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class LoanForm : Form
    {
        List<Loan> borrower = new List<Loan>();
        public LoanForm()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += DataGridView1_SelectionChanged;
            LoadList();
        }
        private void LoadList()
        {

            borrower = SQLiteDataAccess.LoadLoan();
            SQLiteDataAccess dataAccess = new SQLiteDataAccess();
            this.dataGridView1.DataSource = dataAccess.GetDataFromSQLite("select * from Borrower");

        }
        private void DataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewRow row = GetDataFromSelectedRows();
            if (row != null)
            {
                // Use the returned row
                // Example: Print the values of all cells in the row to the Console
                this.bookIdText.Text = row.Cells[1].Value.ToString();
                this.borrowerIdText.Text = row.Cells[2].Value.ToString();
                this.loanDateText.Text = row.Cells[3].Value.ToString();
                this.dueDateText.Text = row.Cells[4].Value.ToString();
                this.returnDateText.Text = row.Cells[5].Value.ToString();
            }
        }

        private DataGridViewRow GetDataFromSelectedRows()
        {
            // Check if any rows are selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the first selected row
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                // Return the selected row
                return row;
            }
            else
            {

                return null;
            }
        }

        private void borrowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BorrowForm borrow = new BorrowForm();

            borrow.Show();

            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void DueDateButton_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = GetDataFromSelectedRows();
            if (row != null)
            {
                // Use the returned row
                // Example: Print the values of all cells in the row to the Console
                this.bookIdText.Text = row.Cells[1].Value.ToString();
                this.borrowerIdText.Text = row.Cells[2].Value.ToString();
                this.loanDateText.Text = row.Cells[3].Value.ToString();
                this.dueDateText.Text = row.Cells[4].Value.ToString();
                this.returnDateText.Text = row.Cells[5].Value.ToString();
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            Loan b = new Loan();

            b.BookId = int.Parse(bookIdText.Text);
            b.BorrowerId = int.Parse(borrowerIdText.Text);
            b.LoanDate = loanDateText.Text;
            b.DueDate = dueDateText.Text;
            b.ReturnDate = returnDateText.Text;
            SQLiteDataAccess.SaveLoan(b);

            bookIdText.Text = "";
            bookIdText.Text = "";
            loanDateText.Text = "";
            dueDateText.Text = "";
            returnDateText.Text = "";

            LoadList();
        }
    }
}
