﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class BorrowForm : Form
    {
        List<Borrow> borrower = new List<Borrow>();
        public BorrowForm()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += DataGridView1_SelectionChanged;
            LoadList();
        }
        private void LoadList()
        {

            borrower = SQLiteDataAccess.LoadBorrow();
            SQLiteDataAccess dataAccess = new SQLiteDataAccess();
            this.dataGridView1.DataSource = dataAccess.GetDataFromSQLite("select * from Borrower");

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Borrow b = new Borrow();

            b.FullName = FullNameText.Text;
            b.PhoneNumber = int.Parse(PhoneNumber.Text);
            b.Address = AddressText.Text;

            SQLiteDataAccess.SaveBorrow(b);

            FullNameText.Text = "";
            PhoneNumber.Text = "";
            AddressText.Text = "";
            LoadList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private DataGridViewRow GetDataFromSelectedRows()
        {
            // Check if any rows are selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the first selected row
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                // Return the selected row
                return row;
            }
            else
            {

                return null;
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = GetDataFromSelectedRows();
            if (row != null)
            {
                // Use the returned row
                // Example: Print the values of all cells in the row to the Console
                this.FullNameText.Text = row.Cells[1].Value.ToString();
                this.PhoneNumber.Text = row.Cells[2].Value.ToString();
                this.AddressText.Text = row.Cells[3].Value.ToString();
            }
        }
        private void DataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewRow row = GetDataFromSelectedRows();
            if (row != null)
            {
                // Use the returned row
                // Example: Print the values of all cells in the row to the Console
                this.FullNameText.Text = row.Cells[1].Value.ToString();
                this.PhoneNumber.Text = row.Cells[2].Value.ToString();
                this.AddressText.Text = row.Cells[3].Value.ToString();
            }
        }

        private void borrowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoanForm loan = new LoanForm();

            loan.Show();

            this.Hide();
        }
   

        private void BorrowForm_Load(object sender, EventArgs e)
        {

        }

        private void PhoneNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddressText_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = GetDataFromSelectedRows();
            if (row != null)
            {
                int borrowerID;
                if (int.TryParse(row.Cells[0].Value.ToString(), out borrowerID))
                {
                    // Get the updated information from the text boxes
                    string author = this.FullNameText.Text;
                    string title = this.PhoneNumber.Text;
                    string publisher = this.AddressText.Text;

                    // Update the borrower information in the database
                    SQLiteDataAccess.UpdateBook(new Book { Id = borrowerID, Author = author, Title = title, Publisher = publisher });

                    // Reload the data in the DataGridView
                    SQLiteDataAccess.LoadBook();
                }
                else
                {
                    MessageBox.Show("Invalid book ID");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = GetDataFromSelectedRows();

            if (selectedRow != null)
            {
                int ID;
                if (int.TryParse(selectedRow.Cells[0].Value.ToString(), out ID))
                {
                    SQLiteDataAccess.DeleteBorrower(ID);
                    dataGridView1.Rows.Remove(selectedRow);
                    MessageBox.Show("Entry deleted successfully.");
                    
                    dataGridView1.DataSource = SQLiteDataAccess.LoadBorrow();
                }
                else
                {
                    MessageBox.Show("Invalid book ID"); // show error message
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void loanToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }


}

