﻿namespace WinFormUI
{
    partial class LoanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.EditButton = new System.Windows.Forms.Button();
            this.AddButton = new System.Windows.Forms.Button();
            this.dueDateText = new System.Windows.Forms.TextBox();
            this.borrowerIdText = new System.Windows.Forms.TextBox();
            this.loanDateText = new System.Windows.Forms.TextBox();
            this.bookIdText = new System.Windows.Forms.TextBox();
            this.returnDateText = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(598, 63);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(800, 538);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(32, 453);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(102, 32);
            this.DeleteButton.TabIndex = 1;
            this.DeleteButton.Text = "Delete";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // EditButton
            // 
            this.EditButton.Location = new System.Drawing.Point(32, 414);
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(102, 33);
            this.EditButton.TabIndex = 2;
            this.EditButton.Text = "Edit";
            this.EditButton.UseVisualStyleBackColor = true;
            // 
            // AddButton
            // 
            this.AddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.AddButton.Location = new System.Drawing.Point(32, 377);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(102, 31);
            this.AddButton.TabIndex = 3;
            this.AddButton.Text = "Add";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // dueDateText
            // 
            this.dueDateText.Location = new System.Drawing.Point(32, 215);
            this.dueDateText.Name = "dueDateText";
            this.dueDateText.Size = new System.Drawing.Size(116, 22);
            this.dueDateText.TabIndex = 4;
            this.dueDateText.Text = "DueDate";
            // 
            // borrowerIdText
            // 
            this.borrowerIdText.Location = new System.Drawing.Point(32, 128);
            this.borrowerIdText.Name = "borrowerIdText";
            this.borrowerIdText.Size = new System.Drawing.Size(116, 22);
            this.borrowerIdText.TabIndex = 5;
            this.borrowerIdText.Text = "BorrowerId";
            // 
            // loanDateText
            // 
            this.loanDateText.Location = new System.Drawing.Point(32, 172);
            this.loanDateText.Name = "loanDateText";
            this.loanDateText.Size = new System.Drawing.Size(116, 22);
            this.loanDateText.TabIndex = 6;
            this.loanDateText.Text = "LoanDate";
            // 
            // bookIdText
            // 
            this.bookIdText.Location = new System.Drawing.Point(32, 84);
            this.bookIdText.Name = "bookIdText";
            this.bookIdText.Size = new System.Drawing.Size(116, 22);
            this.bookIdText.TabIndex = 7;
            this.bookIdText.Text = "BookId";
            // 
            // returnDateText
            // 
            this.returnDateText.Location = new System.Drawing.Point(32, 252);
            this.returnDateText.Name = "returnDateText";
            this.returnDateText.Size = new System.Drawing.Size(116, 22);
            this.returnDateText.TabIndex = 8;
            this.returnDateText.Text = "ReturnDate";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(960, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(92, 22);
            this.textBox1.TabIndex = 9;
            this.textBox1.Text = "  Loan Table";
            // 
            // LoanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1489, 680);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.returnDateText);
            this.Controls.Add(this.bookIdText);
            this.Controls.Add(this.loanDateText);
            this.Controls.Add(this.borrowerIdText);
            this.Controls.Add(this.dueDateText);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.EditButton);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.dataGridView1);
            this.Name = "LoanForm";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button EditButton;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.TextBox dueDateText;
        private System.Windows.Forms.TextBox borrowerIdText;
        private System.Windows.Forms.TextBox loanDateText;
        private System.Windows.Forms.TextBox bookIdText;
        private System.Windows.Forms.TextBox returnDateText;
        private System.Windows.Forms.TextBox textBox1;
    }
}