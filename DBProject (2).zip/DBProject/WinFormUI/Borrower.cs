﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormUI
{
    public class Borrower
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public int PhoneNumber { get; set; }
        public string Address { get; set; }

        public string FullInfo
        {
            get
            {
                return $"{Title} {Author}";
            }
        }
    }
}
